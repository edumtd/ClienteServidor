/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contador.cliente;

/**
 *
 * @author araul
 */


import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

public class Cliente {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Uso: java Cliente 1");
            return;
        }
        String clienteId = args[0];

        try {
            XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
            // IMPORTANTE: Si ejecutas el cliente en otra PC, cambia 127.0.0.1
            // por la IP local del servidor.
            config.setServerURL(new URL("http://172.31.10.27:8080/xmlrpc"));
            XmlRpcClient client = new XmlRpcClient();
            client.setConfig(config);
            
            System.out.println("Cliente '" + clienteId + "' iniciado, conectando al servidor...");
            
            List<Integer> misValores = new ArrayList<>();
            Random random = new Random();

            while (true) {
                Object[] params = new Object[]{clienteId};
                Integer resultado = (Integer) client.execute("contador.incrementar", params);

                if (resultado > 0) {
                    misValores.add(resultado);
                    System.out.println("Éxito. Nuevo valor: " + resultado);
                } else if (resultado == 0) {
                    System.out.println("Turno repetido, esperando...");
                } else if (resultado == -1) {
                    System.out.println("El contador ha finalizado.");
                    break;
                }
                
                Thread.sleep(100 + random.nextInt(200));
            }
            
            System.out.println("\n--- Registro final para '" + clienteId + "' ---");
            System.out.println("Total de valores obtenidos: " + misValores.size());

        } catch (Exception e) {
            System.err.println("Error en el cliente: " + e.getMessage());
        }
    }
}